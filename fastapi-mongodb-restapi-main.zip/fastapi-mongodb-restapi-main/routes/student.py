
from fastapi import APIRouter
from models.student import Student 
from config.db import conn 
from schemas.student import serializeDict, serializeList
from bson import ObjectId
student = APIRouter() 

@student.get('/')
async def find_all_std():
    return serializeList(conn.local.student.find())


@student.post('/')
async def create_std(student: Student):
    conn.local.student.insert_one(dict(student))
    return serializeList(conn.local.student.find())

@student.put('/{id}')
async def update_std(id,student: Student):
    conn.local.student.find_one_and_update({"_id":ObjectId(id)},{
        "$set":dict(student)
    })
    return serializeDict(conn.local.student.find_one({"_id":ObjectId(id)}))

@student.delete('/{id}')
async def delete_std(id,student: Student):
    return serializeDict(conn.local.student.find_one_and_delete({"_id":ObjectId(id)}))